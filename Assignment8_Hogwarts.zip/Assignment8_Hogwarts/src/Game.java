import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class Game {

    public static void main(String[] args) {

        int choice = 0;
        boolean valid = false;
        Explore play = new Explore();
        greeting();

            do {
                try {
                    Scanner scan = new Scanner(System.in);
                    choice = scan.nextInt();
                    if(choice == 1){
                        play.startExploring();
                        valid = true;
                    }
                    else if(choice == 2){
                        quit();
                        valid = true;
                    }
                    else{
                        System.out.println("Choose 1 or 2 please.");
                        valid = false;
                    }

                } catch (InputMismatchException e) {

                    System.out.println("That isn't an option.");
                    valid = false;
                }
            } while (valid == false);
    }


    /**
     * Simple greeting for the start of the game
     */
    public static void greeting(){

        System.out.println("Welcome to Hogwarts, school of witchcraft and wizardry!");
        System.out.println("You stand in the main hall of Hogwarts, you may explore and look around.");
        System.out.println("Would you like to explore? 1 = yes, 2 = no");

    }

    public static void quit(){

        System.out.println("Literally the most magical place on Earth, but whatever... See ya.");
    }

}
