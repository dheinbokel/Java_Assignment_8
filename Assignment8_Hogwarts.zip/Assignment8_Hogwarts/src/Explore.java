import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;
import java.util.Random;

public class Explore {

    private ArrayList<Room> roomList;
    private Room currentRoom;

    public Explore(){

        roomList = new ArrayList<>();
        createRooms();

    }

    /**
     * Creates the rooms in the castle as well as the exits of those rooms.
     */
    public void createRooms(){

            //Creates the rooms in the castle
            Room mainHall = new Room("Main Hall","You see a huge open room with many tables and house flags on the ceiling",20,15,5,"a huge turkey dinner");
            Room changingStairs = new Room("Changing Staircases","You see a large room of staircases and paintings",10,10,5,"several dropped coins");
            Room bridge = new Room("Connecting Bridge","This bridge connects the East and West sections of the school",20,5,10,"a nice wand");
            Room courtyard = new Room("Courtyard","You see a large open area with a beautiful fountain in the center",30,30,10,"a Potter Sucks pin");
            Room darkArts = new Room("Dark Arts Defense Classroom","You see rows of tables and chairs and scorch marks on the walls",30,20,5,"Snape's cloak");
            Room potions = new Room("Potions Classroom","You see a large bubbling cauldron in the center of the room surrounded by desks",20,20,5,"an iffy potion");
            Room spellsCharms = new Room("Spells and Charms Classroom","You see many spells written on the board and many floating feathers",10,12,5,"a spell book");
            Room herbology = new Room("Herbology Classroom","You see many plants around the room and medicine recipes on the board",30,30,5,"bits of weird plants");
            Room greenHouses = new Room("Outdoor Greenhouses","You see a few tables with potted plants with notes warning you about Mandrakes",1,1,5,"mandrake root");
            Room field = new Room("Open Field","You see a rough looking old tree in the middle of a field and feel like you should stay away",15,20,5,"blood");

            //Adds the rooms that were created to the roomList ArrayList to use for random selection of the teleported room
            roomList.add(mainHall);
            roomList.add(changingStairs);
            roomList.add(bridge);
            roomList.add(courtyard);
            roomList.add(darkArts);
            roomList.add(potions);
            roomList.add(spellsCharms);
            roomList.add(herbology);
            roomList.add(greenHouses);
            roomList.add(field);

            //Set the exits of the different rooms
            mainHall.setExit("south", changingStairs);

            changingStairs.setExit("north", mainHall);
            changingStairs.setExit("east", bridge);

            bridge.setExit("west", changingStairs);
            bridge.setExit("east", courtyard);

            courtyard.setExit("west", bridge);
            courtyard.setExit("east", herbology);
            courtyard.setExit("south", darkArts);

            darkArts.setExit("north", courtyard);
            darkArts.setExit("west", potions);
            darkArts.setExit("east", spellsCharms);

            potions.setExit("east", darkArts);

            spellsCharms.setExit("west", darkArts);

            herbology.setExit("west", courtyard);
            herbology.setExit("north", greenHouses);

            greenHouses.setExit("south", herbology);
            greenHouses.setExit("north", field);

            field.setExit("south", greenHouses);

            currentRoom = mainHall;
    }

    public void startExploring(){

        boolean valid = false;
        int choice = 0;
        do {

            System.out.println("***********************************************************************************");
            boolean teleported = false;
            currentRoom.showDetails();
            System.out.println(currentRoom.showExits());
            System.out.println();
            System.out.println("What would you like to do?");
            showOptions();

            try {

                Scanner roomOption = new Scanner(System.in);
                choice = roomOption.nextInt();
                switch (choice){

                    case 1:
                        currentRoom.itemSearch();
                        valid = false;
                        break;
                    case 2:
                        currentRoom.peopleSearch();
                        valid = false;
                        break;
                    case 3:
                        teleported = currentRoom.checkTeleStatus();
                        if(teleported == true){
                            currentRoom = randomTele();
                            System.out.println("***Magical Teleporty Noises***");
                        }
                        else {
                            currentRoom = currentRoom.moveOn();
                        }
                        valid = false;
                        break;
                    case 4:
                        System.out.println("See you later!  You're welcome back any time!");
                        valid = true;
                        break;
                    default:
                        System.out.println("Sorry that is not an option.");
                        valid = false;
                }
            } catch (InputMismatchException e) {
                System.out.println("That is not a valid option.");
            }
        }while(valid == false);
    }

    public Room randomTele(){

        Random newRand = new Random();
        int number = newRand.nextInt(roomList.size());
        Room newRoom = roomList.get(number);

        return newRoom;
    }

    /**
     * Displays the options for the user.
     */
    public void showOptions(){

        System.out.println("Look for items: 1");
        System.out.println("Look for people: 2");
        System.out.println("Head to an exit: 3");
        System.out.println("Quit: 4");
    }
}
