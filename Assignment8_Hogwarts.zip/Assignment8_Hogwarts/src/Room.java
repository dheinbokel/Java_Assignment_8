import java.util.*;

public class Room {

    private String name;
    private String description;
    private int occupiedChance;
    private int itemChance;
    private int teleChance;
    private String item;
    private boolean searched;
    private Random newRand;

    private HashMap<String, Room> roomExits;
    private ArrayList<String> people;

    public Room(String name, String description, int occupiedChance, int itemChance, int teleChance, String item){

        this.name = name;
        this.description = description;
        this.occupiedChance = occupiedChance;
        this.itemChance = itemChance;
        this.teleChance = teleChance;
        this.item = item;
        this.searched = false;
        newRand = new Random();

        roomExits = new HashMap<>();
        people = new ArrayList<>();

        people.add("Harry Potter");
        people.add("Ron Weasley");
        people.add("Hermione Granger");
        people.add("Draco Malfoy");
        people.add("Rubeus Hagrid");
    }

    /**
     * Sets the possible exits of the room and stores it in a hashmap.
     * @param direction
     * @param room
     */
    public void setExit(String direction, Room room){

        roomExits.put(direction, room);
    }

    /**
     * Simply returns the name of the room.
     * @return
     */
    public String getName(){

        return name;
    }

    /**
     * Returns the description of the room.
     * @return
     */
    public String getDescription(){

        return description;
    }

    /**
     * Returns the chance that a room has another person in it.
     * @return
     */
    public int getOccupiedChance(){

        return occupiedChance;
    }

    /**
     * Returns the chance of an item being in the room.
     * @return
     */
    public int getItemChance(){

        return itemChance;
    }

    /**
     * Returns the chance of a random teleport to another room.
     * @return
     */
    public int getTeleChance(){

        return teleChance;
    }

    /**
     * Returns the specific item stored in the room that the player has a chance to find.
     * @return
     */
    public String getItem(){

        return item;
    }

    /**
     * Prints out the details of the room that the student can see.
     */
    public void showDetails(){

        System.out.println("You are in: " + name);
        System.out.println(description);
        System.out.println("You could find " + item + " in this room.");
    }

    /**
     * Displays all possible exits of the current room to the user.  Adds direction to the string to produce
     * a single string of displaying each direction.
     * @return
     */
    public String showExits(){

        String allExits = "Exits:";
        Set<String> keys = roomExits.keySet();
        for(String exits : keys){
            allExits += " " + exits;
        }
        return allExits;
    }

    /**
     * Searches the current room for an item.
     */
    public void itemSearch(){

        int number;

        if(searched == false){
            number = newRand.nextInt(100)+1;
            if(number <= itemChance){
                System.out.println("Alright! You STOLE " + item);
                searched = true;
            }
            else{
                System.out.println("It doesn't look like anything is here to STEAL!");
                searched = true;
            }
        }
        else{
            System.out.println("You already looked here, maybe another area has something you could STEAL.");
        }
    }

    /**
     * Searches for people occupying the room with the user.
     */
    public void peopleSearch(){

        Random randPerson = new Random();
        int number;
        int personSearch;
        number = newRand.nextInt(100)+1;

        if(number <= occupiedChance){

            personSearch = randPerson.nextInt(people.size());
            System.out.println("Hey, it's " + people.get(personSearch) +". We shouldn't bother this person though, they're my senior after all.");
        }
        else{
            System.out.println("It doesn't look like anyone is here...");
        }
    }

    /**
     * Picks what room the current room will be moved to and returns the Room.
     * @return
     */
    public Room moveOn(){

        Room decision = null;
        boolean valid = false;
        showExits();
        System.out.println("Where would you like to go? Input the direction of the exit (Example: north).");

        do{
            Scanner direction = new Scanner(System.in);
            String exitChoice = direction.nextLine();

            if(roomExits.get(exitChoice) == null){
                System.out.println("Sorry, that is not a valid exit.");
                valid = false;
            }
            else{
                decision = roomExits.get(exitChoice);
                valid = true;
            }
        }while(valid == false);

        return decision;
    }

    public boolean checkTeleStatus(){

        boolean teleport = false;
        Random newRand = new Random();
        int number = newRand.nextInt(100)+1;

        if(number <= teleChance){

            teleport = true;
        }
        else{
            teleport = false;
        }

        return teleport;
    }
}
